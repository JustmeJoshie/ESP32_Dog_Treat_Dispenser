/*
 * SPDX-FileCopyrightText: 2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Unlicense OR CC0-1.0
 */
#pragma once
#define IRAM_ATTR
#define FLAG_ATTR(TYPE)
#define QUEUE_H
#define __ARCH_CC_H__
#define __XTENSA_API_H__
#define SSIZE_MAX INT_MAX
#define LWIP_HDR_IP6_ADDR_H
#define LWIP_HDR_IP4_ADDR_H
